import json

# List to store data from each JSON file
combined_data = []

# List of file names (replace these with your actual file names)
json_files = ["test_"+str(i) + "_stats.json" for i in range(1, 101)]

# Loop through each file
for file_name in json_files:
    with open(file_name, 'r') as file:
        # Load JSON data from the file
        data = json.load(file)
        
        # Append data to the combined_data list
        combined_data.append(data)

# Combine all data into a single dictionary or list, depending on your JSON structure
# For example, if your JSON files contain a list of objects, you can use extend() to combine them into a single list
# If your JSON files contain a dictionary, you can merge them into a single dictionary
# For simplicity, let's assume they contain a list of objects
result_data = []
result_data.extend(combined_data)

# Write the combined data to a new file
with open("combined_file.json", 'w') as combined_file:
    json.dump(result_data, combined_file, indent=2)

print("Combined JSON files into 'combined_file.json'")
